import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-value',
  templateUrl: './our-value.component.html',
  styleUrls: ['./our-value.component.css']
})
export class OurValueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
