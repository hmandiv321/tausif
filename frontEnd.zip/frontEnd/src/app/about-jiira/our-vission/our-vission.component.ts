import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-vission',
  templateUrl: './our-vission.component.html',
  styleUrls: ['./our-vission.component.css']
})
export class OurVissionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
