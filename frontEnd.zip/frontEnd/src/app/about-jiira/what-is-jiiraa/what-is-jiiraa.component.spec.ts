import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhatIsJiiraaComponent } from './what-is-jiiraa.component';

describe('WhatIsJiiraaComponent', () => {
  let component: WhatIsJiiraaComponent;
  let fixture: ComponentFixture<WhatIsJiiraaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhatIsJiiraaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhatIsJiiraaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
