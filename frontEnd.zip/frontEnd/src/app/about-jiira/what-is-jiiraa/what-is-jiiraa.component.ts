import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-what-is-jiiraa',
  templateUrl: './what-is-jiiraa.component.html',
  styleUrls: ['./what-is-jiiraa.component.css']
})
export class WhatIsJiiraaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
