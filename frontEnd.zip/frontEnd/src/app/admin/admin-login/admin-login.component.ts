import { Component, OnInit } from "@angular/core";
import { GlobalLoginService } from "src/app/services/global-login.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-admin-login",
  templateUrl: "./admin-login.component.html",
  styleUrls: ["./admin-login.component.css"],
})
export class AdminLoginComponent implements OnInit {
  constructor(
    private router: Router,
    private globalLoginService: GlobalLoginService
  ) {}

  ngOnInit() {}

  login() {
    // log out supplier user
    this.globalLoginService.setSupplierLoginButtonToFalse();
    this.globalLoginService.setUserIsSupplierToFalse();

    // log in admin user
    this.globalLoginService.setUsername("Admin");
    this.globalLoginService.setAdminLoginButtonToFalse();
    this.globalLoginService.setUserIsAdminToTrue();
    this.router.navigate(["/"]);
  }
}
