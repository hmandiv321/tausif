import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-manage-users',
  templateUrl: './admin-manage-users.component.html',
  styleUrls: ['./admin-manage-users.component.css']
})
export class AdminManageUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
