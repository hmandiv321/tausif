import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { ProductsComponent } from "./products/products.component";
import { DonationsCartComponent } from "./donations-cart/donations-cart.component";
import { DonationsCheckOutComponent } from "./donations-check-out/donations-check-out.component";
import { DonationsOrderSuccessComponent } from "./donations-order-success/donations-order-success.component";
import { LoginComponent } from "./suppliers/login/login.component";
import { AdminLoginComponent } from "./admin/admin-login/admin-login.component";
import { AdminProductsComponent } from "./admin/admin-products/admin-products.component";
import { AdminOrdersComponent } from "./admin/admin-orders/admin-orders.component";
import { AdminManageUsersComponent } from "./admin/admin-manage-users/admin-manage-users.component";
import { OurServicesComponent } from "./main-menu/our-services/our-services.component";
import { OurSupportersComponent } from "./main-menu/our-supporters/our-supporters.component";
import { OurPartnersComponent } from "./main-menu/our-partners/our-partners.component";
import { BecomeASupplierComponent } from "./main-menu/become-a-supplier/become-a-supplier.component";
import { MediaCoveragesComponent } from "./main-menu/media-coverages/media-coverages.component";
import { WhatIsJiiraaComponent } from "./about-jiira/what-is-jiiraa/what-is-jiiraa.component";
import { OurMissionComponent } from "./about-jiira/our-mission/our-mission.component";
import { OurVissionComponent } from "./about-jiira/our-vission/our-vission.component";
import { OurValueComponent } from "./about-jiira/our-value/our-value.component";
import { ImpactComponent } from "./main-menu/impact/impact.component";
import { TeamComponent } from "./main-menu/team/team.component";
import { HowItWorksComponent } from "./how-it-works/how-it-works.component";
import { TestimonialsComponent } from "./testimonials/testimonials.component";
import { FaqComponent } from "./faq/faq.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "how-it-works", component: HowItWorksComponent },
  { path: "faq", component: FaqComponent },
  { path: "testimonials", component: TestimonialsComponent },
  { path: "products", component: ProductsComponent },
  { path: "cart", component: DonationsCartComponent },
  { path: "checkout", component: DonationsCheckOutComponent },
  { path: "order-success", component: DonationsOrderSuccessComponent },
  { path: "suppliers/login", component: LoginComponent },
  { path: "admin/login", component: AdminLoginComponent },
  { path: "admin/manage-users", component: AdminManageUsersComponent },
  { path: "admin/products", component: AdminProductsComponent },
  { path: "admin/orders", component: AdminOrdersComponent },
  { path: "menu/services", component: OurServicesComponent },
  { path: "menu/supporters", component: OurSupportersComponent },
  { path: "menu/partners", component: OurPartnersComponent },
  { path: "menu/become-a-supplier", component: BecomeASupplierComponent },
  { path: "menu/media-coverages", component: MediaCoveragesComponent },
  { path: "about-jiira/what-is-jiiraa", component: WhatIsJiiraaComponent },
  { path: "about-jiira/mission", component: OurMissionComponent },
  { path: "about-jiira/vission", component: OurVissionComponent },
  { path: "about-jiira/values", component: OurValueComponent },
  { path: "about-jiira/impact", component: ImpactComponent },
  { path: "about-jiira/team", component: TeamComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
