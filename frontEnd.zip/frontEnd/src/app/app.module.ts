import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BsNavbarComponent } from "./bs-navbar/bs-navbar.component";
import { HomeComponent } from "./home/home.component";
import { ProductsComponent } from "./products/products.component";
import { DonationsCartComponent } from "./donations-cart/donations-cart.component";
import { DonationsCheckOutComponent } from "./donations-check-out/donations-check-out.component";
import { DonationsOrderSuccessComponent } from "./donations-order-success/donations-order-success.component";
import { AdminProductsComponent } from "./admin/admin-products/admin-products.component";
import { AdminOrdersComponent } from "./admin/admin-orders/admin-orders.component";
import { AdminLoginComponent } from "./admin/admin-login/admin-login.component";
import { LoginComponent } from "./suppliers/login/login.component";
import { AdminManageUsersComponent } from "./admin/admin-manage-users/admin-manage-users.component";
import { OurServicesComponent } from "./main-menu/our-services/our-services.component";
import { OurSupportersComponent } from "./main-menu/our-supporters/our-supporters.component";
import { OurPartnersComponent } from "./main-menu/our-partners/our-partners.component";
import { BecomeASupplierComponent } from "./main-menu/become-a-supplier/become-a-supplier.component";
import { MediaCoveragesComponent } from "./main-menu/media-coverages/media-coverages.component";
import { WhatIsJiiraaComponent } from "./about-jiira/what-is-jiiraa/what-is-jiiraa.component";
import { OurMissionComponent } from "./about-jiira/our-mission/our-mission.component";
import { OurVissionComponent } from "./about-jiira/our-vission/our-vission.component";
import { OurValueComponent } from "./about-jiira/our-value/our-value.component";
import { ImpactComponent } from "./main-menu/impact/impact.component";
import { TeamComponent } from "./main-menu/team/team.component";
import { HowItWorksComponent } from "./how-it-works/how-it-works.component";
import { FaqComponent } from "./faq/faq.component";
import { TestimonialsComponent } from "./testimonials/testimonials.component";
import { FaInputComponent } from "./utils/fa-input/fa-input.component";

@NgModule({
  declarations: [
    AppComponent,
    BsNavbarComponent,
    HomeComponent,
    ProductsComponent,
    DonationsCartComponent,
    DonationsCheckOutComponent,
    DonationsOrderSuccessComponent,
    AdminProductsComponent,
    AdminOrdersComponent,
    AdminLoginComponent,
    LoginComponent,
    AdminManageUsersComponent,
    OurServicesComponent,
    OurSupportersComponent,
    OurPartnersComponent,
    BecomeASupplierComponent,
    MediaCoveragesComponent,
    WhatIsJiiraaComponent,
    OurMissionComponent,
    OurVissionComponent,
    OurValueComponent,
    ImpactComponent,
    TeamComponent,
    HowItWorksComponent,
    FaqComponent,
    TestimonialsComponent,
    FaInputComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, NgbModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
