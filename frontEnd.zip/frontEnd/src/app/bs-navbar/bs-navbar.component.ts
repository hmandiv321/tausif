import { Component, OnInit } from "@angular/core";
import { GlobalLoginService } from "../services/global-login.service";

@Component({
  selector: "jiraa-navbar",
  templateUrl: "./bs-navbar.component.html",
  styleUrls: ["./bs-navbar.component.css"],
})
export class BsNavbarComponent {
  constructor(public globalLoginService: GlobalLoginService) {}

  public adminLogout() {
    this.globalLoginService.setUsername("");
    this.globalLoginService.setAdminLoginButtonToTrue();
    this.globalLoginService.setSupplierLoginButtonToTrue();
    this.globalLoginService.setUserIsAdminToFalse();
  }
  public supplierLogout() {
    this.globalLoginService.setUsername("");
    this.globalLoginService.setAdminLoginButtonToTrue();
    this.globalLoginService.setSupplierLoginButtonToTrue();
    this.globalLoginService.setUserIsSupplierToFalse();
  }
}
