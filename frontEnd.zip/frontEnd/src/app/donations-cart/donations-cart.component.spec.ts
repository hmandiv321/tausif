import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationsCartComponent } from './donations-cart.component';

describe('DonationsCartComponent', () => {
  let component: DonationsCartComponent;
  let fixture: ComponentFixture<DonationsCartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationsCartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationsCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
