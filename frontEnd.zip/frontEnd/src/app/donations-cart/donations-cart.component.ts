import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donations-cart',
  templateUrl: './donations-cart.component.html',
  styleUrls: ['./donations-cart.component.css']
})
export class DonationsCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
