import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationsCheckOutComponent } from './donations-check-out.component';

describe('DonationsCheckOutComponent', () => {
  let component: DonationsCheckOutComponent;
  let fixture: ComponentFixture<DonationsCheckOutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationsCheckOutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationsCheckOutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
