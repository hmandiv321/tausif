import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donations-check-out',
  templateUrl: './donations-check-out.component.html',
  styleUrls: ['./donations-check-out.component.css']
})
export class DonationsCheckOutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
