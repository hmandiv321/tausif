import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationsOrderSuccessComponent } from './donations-order-success.component';

describe('DonationsOrderSuccessComponent', () => {
  let component: DonationsOrderSuccessComponent;
  let fixture: ComponentFixture<DonationsOrderSuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationsOrderSuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationsOrderSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
