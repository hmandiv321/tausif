import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donations-order-success',
  templateUrl: './donations-order-success.component.html',
  styleUrls: ['./donations-order-success.component.css']
})
export class DonationsOrderSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
