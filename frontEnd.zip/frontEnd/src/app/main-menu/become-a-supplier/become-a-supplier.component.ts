import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-become-a-supplier',
  templateUrl: './become-a-supplier.component.html',
  styleUrls: ['./become-a-supplier.component.css']
})
export class BecomeASupplierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
