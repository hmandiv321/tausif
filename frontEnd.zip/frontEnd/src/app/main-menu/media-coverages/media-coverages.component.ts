import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-coverages',
  templateUrl: './media-coverages.component.html',
  styleUrls: ['./media-coverages.component.css']
})
export class MediaCoveragesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
