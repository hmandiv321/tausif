import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-supporters',
  templateUrl: './our-supporters.component.html',
  styleUrls: ['./our-supporters.component.css']
})
export class OurSupportersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
