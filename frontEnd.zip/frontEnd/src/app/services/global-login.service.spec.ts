import { TestBed } from '@angular/core/testing';

import { GlobalLoginService } from './global-login.service';

describe('GlobalLoginService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GlobalLoginService = TestBed.get(GlobalLoginService);
    expect(service).toBeTruthy();
  });
});
