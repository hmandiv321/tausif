import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class GlobalLoginService {
  constructor() {}
  public username = "";
  public showSupplierLoginButton = true;
  public showAdminLoginButton = true;
  public userIsSupplier = false;
  public userIsAdmin = false;
  setUsername(username) {
    this.username = username;
  }
  getUsername() {
    return this.username;
  }
  setSupplierLoginButtonToTrue() {
    this.showSupplierLoginButton = true;
  }
  setSupplierLoginButtonToFalse() {
    this.showSupplierLoginButton = false;
  }
  getShowSupplierLoginButton() {
    return this.showSupplierLoginButton;
  }
  setAdminLoginButtonToTrue() {
    this.showAdminLoginButton = true;
  }
  setAdminLoginButtonToFalse() {
    this.showAdminLoginButton = false;
  }
  getShowAdminLoginButton() {
    return this.showAdminLoginButton;
  }
  setUserIsSupplierToTrue() {
    this.userIsSupplier = true;
  }
  setUserIsSupplierToFalse() {
    this.userIsSupplier = false;
  }
  getUserIsSupplier() {
    return this.userIsSupplier;
  }
  setUserIsAdminToTrue() {
    this.userIsAdmin = true;
  }
  setUserIsAdminToFalse() {
    this.userIsAdmin = false;
  }
  getUserIsAdmin() {
    return this.userIsAdmin;
  }
}
